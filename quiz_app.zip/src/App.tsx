import React from "react";
import logo from "./logo.svg";
import "./App.css";
import Quiz_app from "./Page/Quiz_app";
import Question from "./Page/Question"
import { BrowserRouter, Routes, Route } from "react-router-dom";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Quiz_app />}/>
        <Route path="/quiz" element={<Question/>}/> 
      </Routes>
    </BrowserRouter>
  );
}

export default App;
