import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function Quiz_app() {
  const [difficulty, setDifficulty] = useState("");
  const navigate = useNavigate();

  const handleStart = (e: React.FormEvent) => {
    e.preventDefault();
    if (!difficulty) {
      alert("❌ Please select a difficulty!");
      return;
    }
    navigate(`/quiz?difficulty=${difficulty}`);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-black text-white">
      <form
        onSubmit={handleStart}
        className="border-2 p-10 rounded-lg bg-white text-black mb-6"
      >
        <h1 className="text-2xl font-bold mb-2">Quiz App</h1>
        <h2 className="text-lg mb-4">General Knowledge</h2>

        <select
          value={difficulty}
          onChange={(e) => setDifficulty(e.target.value)}
          className="border p-2 rounded mb-4 w-full"
        >
          <option value="">Pick Difficulty</option>
          <option value="easy">Easy</option>
          <option value="medium">Medium</option>
          <option value="hard">Hard</option>
        </select>

        <button
          type="submit"
          className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded"
        >
          Start
        </button>
      </form>
    </div>
  );
}

export default Quiz_app;
