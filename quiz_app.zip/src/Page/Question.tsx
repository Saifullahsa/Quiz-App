import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";

type QuestionType = {
  question: string;
  correct_answer: string;
  incorrect_answers: string[];
};

function Question() {
  const [searchParams] = useSearchParams();
  const difficulty = searchParams.get("difficulty") || "";
  const [questions, setQuestions] = useState<QuestionType[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (difficulty) {
      const url = `https://opentdb.com/api.php?amount=10&category=9&difficulty=${difficulty}&type=multiple`;
      fetch(url)
        .then((res) => res.json())
        .then((data) => {
          if (data.response_code === 0 && Array.isArray(data.results)) {
            setQuestions(data.results);
          } else {
            console.warn("No questions found for:", difficulty);
            setQuestions([]);
          }
          setLoading(false);
        })
        .catch((err) => {
          console.error(err);
          setQuestions([]);
          setLoading(false);
        });
    } else {
      setQuestions([]);
      setLoading(false);
    }
  }, [difficulty]);

  if (loading) {
    return <div className="text-white text-center mt-10">Loading...</div>;
  }

  if (questions.length === 0) {
    return (
      <div className="text-black text-center mt-10">
        ❌ No questions found for this difficulty.
      </div>
    );
  }

  return (
    <div className="p-10 text-white">
      <h1 className="text-2xl font-bold mb-6">
        Quiz - {difficulty.toUpperCase()} Mode
      </h1>
      {questions.map((q, index) => (
        <div key={index} className="mb-6 p-4 border rounded bg-gray-800">
          <h2 className="mb-3" dangerouslySetInnerHTML={{ __html: q.question }} />
          {[...q.incorrect_answers, q.correct_answer]
            .sort(() => Math.random() - 0.5)
            .map((option, idx) => (
              <div key={idx} className="mb-2">
                <button
                  className="bg-blue-500 hover:bg-blue-600 px-3 py-1 rounded"
                  dangerouslySetInnerHTML={{ __html: option }}
                />
              </div>
            ))}
        </div>
      ))}
    </div>
  );
}

export default Question;
